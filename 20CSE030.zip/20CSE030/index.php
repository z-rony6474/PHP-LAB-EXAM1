<?php
	include "dbcont.php";
?>

<!DOCTYPE html>
<html lang="en">
<body>	
	
		<center>

			<h1>Welcome To PHP Lab</h1>
		  <pre><h2>Don't have an account?  <a href="registration.php"><button style="background-color:#0c3294;border: none;padding: 15px;border-radius: 10px;color:white;">Registration </button></a></h2></pre><br>
		   <pre><h2>Already have an account?  <a href="login.php"><button style="background-color:#0c3294;border: none;padding: 15px;border-radius: 10px;color:white;">Sign In</button></a></h2></pre>
		</center>
	
</body>
</html>




